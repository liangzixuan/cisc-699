"""SafeExec W5 implementation baseline."""

__all__ = ["__version__"]

__version__ = "0.1.0"
